import SpriteKit

final class BuddyNode: SKSpriteNode {

    let animation = AnimationController()

    init() {

        let idleFrames = TextureLibrary.shared.idle

        super.init(
            texture: idleFrames.first,
            color: .clear,
            size: idleFrames.first?.size() ?? CGSize(width: 220, height: 220)
        )

        name = "Buddy"

        let action = SKAction.animate(
            with: TextureLibrary.shared.idle,
            timePerFrame: 0.4,
            resize: false,
            restore: false
        )

        run(SKAction.repeatForever(action))
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
