import SpriteKit

final class AnimationController {

    enum State {
        case idle
        case walk
        case run
        case sit
        case sleep
        case tailWag
        case play
    }

    private var currentState: State?

    private let animationKey = "BuddyAnimation"

    func play(_ state: State, on buddy: SKSpriteNode) {

        guard currentState != state else { return }

        currentState = state

        buddy.removeAction(forKey: animationKey)

        let textures: [SKTexture]
        let frameTime: TimeInterval

        switch state {

        case .idle:
            textures = TextureLibrary.shared.idle
            frameTime = 0.15

        case .walk:
            textures = TextureLibrary.shared.walk
            frameTime = 0.10

        case .run:
            textures = TextureLibrary.shared.idle
            frameTime = 0.15

        case .sit:
            textures = TextureLibrary.shared.sit
            frameTime = 0.12

        case .sleep:
            textures = TextureLibrary.shared.sleep
            frameTime = 0.18

        case .tailWag:
            textures = TextureLibrary.shared.tailWag
            frameTime = 0.10

        case .play:
            textures = TextureLibrary.shared.play
            frameTime = 0.08
        }

        guard !textures.isEmpty else { return }

        buddy.texture = textures.first

        let animate = SKAction.animate(
            with: textures,
            timePerFrame: frameTime,
            resize: false,
            restore: false
        )

        let forever = SKAction.repeatForever(animate)

        buddy.run(
            forever,
            withKey: animationKey
        )
    }
}
