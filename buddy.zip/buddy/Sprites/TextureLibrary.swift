import SpriteKit

final class TextureLibrary {

    static let shared = TextureLibrary()

    private init() {}

    let idle = TextureLibrary.loadFrames(
        prefix: "idle",
        count: 8
    )

    let walk = TextureLibrary.loadFrames(
        prefix: "walk",
        count: 8
    )
    let run: [SKTexture] = []
    let sit: [SKTexture] = []
    let sleep: [SKTexture] = []
    let tailWag: [SKTexture] = []
    let play: [SKTexture] = []
    let enterHouse: [SKTexture] = []

    private static func loadFrames(
        prefix: String,
        count: Int
    ) -> [SKTexture] {

        var textures: [SKTexture] = []

        for index in 1...count {

            let name = String(
                format: "%@_%02d",
                prefix,
                index
            )

            let texture = SKTexture(imageNamed: name)
            texture.filteringMode = .nearest


            textures.append(texture)
        }

        return textures
    }
}
