import SpriteKit

final class BuddyScene: SKScene {

    private let buddy = BuddyNode()
    private let movementController = MovementController()

    override func didMove(to view: SKView) {

        backgroundColor = .clear

        if let screen = NSScreen.main {
            size = screen.frame.size
        }

        buddy.position = CGPoint(
            x: size.width / 2,
            y: size.height / 2
        )

        addChild(buddy)
    } 

    override func update(_ currentTime: TimeInterval) {

        // Mouse position in screen coordinates
        let mouse = MouseTracker.shared.location

        guard let view = self.view,
              let window = view.window else {
            return
        }

        // Convert screen → window
        let windowPoint = window.convertPoint(fromScreen: mouse)

        // Convert window → SpriteKit scene
        let scenePoint = convertPoint(fromView: windowPoint)

        DesktopPetController.shared.updateTarget(scenePoint)

        let velocityX = movementController.velocity.x

        if abs(velocityX) > 1.5 {

            if velocityX > 0 {
                buddy.xScale = -abs(buddy.xScale)
            } else {
                buddy.xScale = abs(buddy.xScale)
            }
        }

        // Move Buddy
        buddy.position = movementController.update(
            position: buddy.position,
            target: scenePoint
        )

        // Calculate Buddy's movement speed
        let speed = sqrt(
            movementController.velocity.x * movementController.velocity.x +
            movementController.velocity.y * movementController.velocity.y
        )

        // Play animations
        if speed < 0.5 {
            buddy.animation.play(.idle, on: buddy)
        } else if speed < 5.0 {
            buddy.animation.play(.walk, on: buddy)
        } else {
            buddy.animation.play(.walk, on: buddy)
        }
    }
    
}
